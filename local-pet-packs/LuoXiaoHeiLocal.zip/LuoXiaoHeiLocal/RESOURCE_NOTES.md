# Luo Xiaohei Local Pack Notes

Generated from the local checkout at `external_assets/IXiaoHei`.

The upstream project uses `shake-head-txt.gif` as its main continuous desktop
pet animation, `playing guitar.gif` as the only random click action,
`eat drumstick.gif` for food, `licking the claw.gif` for bath/cleaning, and
`bye.gif` for exit. The Focus Pet mapping now follows those source semantics:
default/focus uses the main shake-head loop; break uses guitar; ambient stretch
uses grooming; food/recovery uses drumstick; away uses bye.

The upstream static mood and item images are preserved under `props/` for future
interaction work, but they are not mapped to `PetAction` because they are UI
overlays or inventory items rather than desktop pet body animations.

This is a third-party IP resource and should stay local-only unless rights are
confirmed.
