# UNIkeN Local Pack Notes

Generated from the supplied `spritesheet.webp` and source `pet.json`.

The source manifest only includes identity metadata and the spritesheet path, so
frame groups were inferred from the 1536x1872 spritesheet as an 8x9 grid of
192x208 cells. Empty cells were skipped.

Semantic mapping:
- Row 0: smile/idle loop.
- Rows 1-2: running and screen-transfer movement.
- Row 3: wave/welcome/mouse summon.
- Row 4: cheer/focus start/break end.
- Row 5: sitting sleep and sad sitting.
- Row 6: happy idle/focus stable.
- Row 7: annoyed/distracted look/dragged.
- Row 8: strong nudge.
