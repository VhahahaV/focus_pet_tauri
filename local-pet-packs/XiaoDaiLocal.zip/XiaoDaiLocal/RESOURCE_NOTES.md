# XiaoDai Local Pack Notes

Generated from `/Users/vhahahav/Downloads/小呆.zip`.

Source behavior highlights:
- `focus` is the explicit work/focus animation and is mapped to Focus Pet's
  focus actions.
- `stand` is neutral idle.
- `sleep` is true away/sleep; `sleepy` is used for wake/stretch transitions.
- `disturbed`, `patpat2`, and `playball` form the distracted/gentle/strong
  reminder ladder.
- `onfloor`, `drag`, `fall`, `rightwalk`, and `edge` preserve desktop-specific
  rest, drag, landing, movement, and edge behavior.

No audio files are present in the supplied zip.
