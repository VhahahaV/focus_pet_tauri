# Pixel Cat Meme Local Pack Notes

Generated from `/Users/vhahahav/Downloads/像素猫meme.zip`.

Source behavior highlights:
- `work` explicitly says "working" and is mapped to Focus Pet's work/focus
  actions.
- `stand`, `hide`, `touch`, `ybfist`, `ccpkq`, `dance`, `drag`, `onfloor`,
  `rightwalk`, and `feed_1` cover idle, distracted look, gentle nudge, strong
  nudge, break, break end, drag, landing, movement, and mouse summon.
- The source note file references `chibi.wav`, while the archive stores
  `chibi.WAV`; generation normalizes copied audio paths to lowercase.
- Long ambient focus actions intentionally do not play audio, while discrete
  transitions and nudges do.
